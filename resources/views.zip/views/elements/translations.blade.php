<script>
    window.translations = {!! Cache::get('translations') !!};
</script>
