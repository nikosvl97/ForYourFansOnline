@for($i=0;$i<(isset($limit) ? $limit : 0);$i++)
    <div class="ph-item mt-0 mb-2">
        <div class="ph-col-2">
            <div class="ph-avatar"></div>
        </div>
        <div>
            <div class="ph-row">
                <div class="ph-col-12"></div>
                <div class="ph-col-6"></div>
                <div class="ph-col-6 empty"></div>
                <div class="ph-col-2"></div>
                <div class="ph-col-10 empty"></div>
                <div class="ph-col-6"></div>
                <div class="ph-col-6 empty"></div>
            </div>
        </div>
    </div>
@endfor
