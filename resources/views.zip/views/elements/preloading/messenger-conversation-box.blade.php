<div class="ph-item border-0 conversation-loading-box d-none">
    <div class="ph-col-12">
        <div class="ph-row">
            <div class="ph-col-6 big"></div>
            <div class="ph-col-4 empty big"></div>
            <div class="ph-col-2 empty big"></div>

            <div class="ph-col-4 big"></div>
            <div class="ph-col-6 empty big"></div>
            <div class="ph-col-2 empty big"></div>

            <div class="ph-col-6 empty big"></div>
            <div class="ph-col-4 empty big"></div>
            <div class="ph-col-2 big"></div>

            <div class="ph-col-6 empty big"></div>
            <div class="ph-col-2 empty big"></div>
            <div class="ph-col-4 big"></div>

            <div class="ph-col-6 empty big"></div>
            <div class="ph-col-4 empty big"></div>
            <div class="ph-col-2 big"></div>

            <div class="ph-col-2 big"></div>
            <div class="ph-col-4 empty big"></div>
            <div class="ph-col-6 empty big"></div>

            <div class="ph-col-4 big"></div>
            <div class="ph-col-6 empty big"></div>
            <div class="ph-col-2 empty big"></div>

        </div>
    </div>
</div>
