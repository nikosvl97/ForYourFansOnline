<div class="comments-loading-container">
    <div class="ph-item mt-4 shadow-sm rounded">
        <div class="ph-col-2 ph-picture ph-avatar"></div>
        <div class="ph-col-10">
            <div class="ph-row">
                <div class="ph-col-12 big"></div>
            </div>
            <div class="ph-row">
                <div class="ph-col-12 big"></div>
            </div>
            <div class="ph-row">
                <div class="ph-col-12 big"></div>
            </div>
            <div class="ph-row">
                <div class="ph-col-12 big"></div>
            </div>
        </div>
    </div>
</div>
