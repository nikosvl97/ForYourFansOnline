<div class="ph-item border-top-0 border-right-0 border-left-0 mb-0 d-none conversation-header-loading-box">
    <div class="ph-col-2">
        <div class="ph-avatar"></div>
    </div>
    <div>
        <div class="ph-row">
            <div class="ph-col-8 empty"></div>
            <div class="ph-col-4"></div>
            <div class="ph-col-6 empty"></div>
            <div class="ph-col-6"></div>
            <div class="ph-col-10 empty"></div>
            <div class="ph-col-2"></div>
        </div>
    </div>
</div>
